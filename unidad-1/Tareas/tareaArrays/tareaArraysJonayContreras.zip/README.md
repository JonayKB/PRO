<div align = "Justify">


# Tarea Metodos Arrays Jonay Contreras
1. [Ejercicio1](src/main/java/ies/puerto/Ejercicio1.java)
- [Tests](src/test/java/ies/puerto/Ejercicio1Test.java)
---
2. [Ejercicio2](src/main/java/ies/puerto/Ejercicio2.java)
- [Tests](src/test/java/ies/puerto/Ejercicio2Test.java)
---
3. [Ejercicio3](src/main/java/ies/puerto/Ejercicio3.java)
- [Tests](src/test/java/ies/puerto/Ejercicio3Test.java)
---
4. [Ejercicio4](src/main/java/ies/puerto/Ejercicio4.java)
- [Tests](src/test/java/ies/puerto/Ejercicio4Test.java)
---
5. [Ejercicio5](src/main/java/ies/puerto/Ejercicio5.java)
- [Tests](src/test/java/ies/puerto/Ejercicio5Test.java)
---
6. [Ejercicio6](src/main/java/ies/puerto/Ejercicio6.java)
- [Tests](src/test/java/ies/puerto/Ejercicio6Test.java)
---
7. [Ejercicio7](src/main/java/ies/puerto/Ejercicio7.java)
- [Tests](src/test/java/ies/puerto/Ejercicio7Test.java)
---
8. [Ejercicio8](src/main/java/ies/puerto/Ejercicio8.java)
- [Tests](src/test/java/ies/puerto/Ejercicio8Test.java)
---
9. [Ejercicio9](src/main/java/ies/puerto/Ejercicio9.java)
- [Tests](src/test/java/ies/puerto/Ejercicio9Test.java)
---
10. [Ejercicio10](src/main/java/ies/puerto/Ejercicio10.java)
- [Tests](src/test/java/ies/puerto/Ejercicio10Test.java)
---


</div>